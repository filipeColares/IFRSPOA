drop table curso cascade constraints;
drop table disciplina cascade constraints;
drop table aluno cascade constraints;
drop table professor cascade constraints;
drop table turma cascade constraints;
drop table turma_aluno cascade constraints;
drop table aluno_curso cascade constraints;

drop sequence s_id_curso;
drop sequence s_id_disciplina;
drop sequence s_id_aluno;
drop sequence s_id_professor;
drop sequence s_id_turma;